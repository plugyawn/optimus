# Dense Gaussian Parity Report

## lora

| metric | value |
| --- | ---: |
| shared candidates | 16 |
| Spearman | 0.10813008130081299 |
| top-8 overlap | 4 |
| selected regret | 0.046875 |
| dense best cap-hit | 0.0 |
| dense best malformed | 0.0 |
| selected candidate cap-hit | 0.0 |
| selected candidate malformed | 0.0 |
| dense candidate/sec | 0.04186750445400022 |
| candidate/sec | 0.03536823327364456 |
| speed ratio candidate/dense | 0.8447657374110653 |
| dense mean mutation s | 1.4850405603647232 |
| candidate mean mutation s | 0.07420630753040314 |
| mutation ratio candidate/dense | 0.049969212633611974 |
| dense best ensemble holdout | 0.08984375 |
| candidate best ensemble holdout | 0.08984375 |
| ensemble holdout delta | 0.0 |

| gate | pass |
| --- | ---: |
| shared_panel | true |
| spearman | false |
| topk_overlap | false |
| selected_regret | false |
| speed | false |
| ensemble_quality | true |

Pass: `false`

## projected

| metric | value |
| --- | ---: |
| shared candidates | 16 |
| Spearman | 0.332520325203252 |
| top-8 overlap | 6 |
| selected regret | 0.0 |
| dense best cap-hit | 0.0 |
| dense best malformed | 0.0 |
| selected candidate cap-hit | 0.0 |
| selected candidate malformed | 0.0 |
| dense candidate/sec | 0.04186750445400022 |
| candidate/sec | 0.009925744667235704 |
| speed ratio candidate/dense | 0.237075144474902 |
| dense mean mutation s | 1.4850405603647232 |
| candidate mean mutation s | 56.92297823727131 |
| mutation ratio candidate/dense | 38.33092492995015 |
| dense best ensemble holdout | 0.08984375 |
| candidate best ensemble holdout | 0.08984375 |
| ensemble holdout delta | 0.0 |

| gate | pass |
| --- | ---: |
| shared_panel | true |
| spearman | false |
| topk_overlap | true |
| selected_regret | true |
| speed | false |
| ensemble_quality | true |

Pass: `false`

## randomized_projected

| metric | value |
| --- | ---: |
| shared candidates | 16 |
| Spearman | 0.48399626651671684 |
| top-8 overlap | 7 |
| selected regret | 0.015625 |
| dense best cap-hit | 0.0 |
| dense best malformed | 0.0 |
| selected candidate cap-hit | 0.0 |
| selected candidate malformed | 0.0 |
| dense candidate/sec | 0.04186750445400022 |
| candidate/sec | 0.028178624517103113 |
| speed ratio candidate/dense | 0.6730428499282286 |
| dense mean mutation s | 1.4850405603647232 |
| candidate mean mutation s | 5.040386751294136 |
| mutation ratio candidate/dense | 3.3941071279940167 |
| dense best ensemble holdout | 0.08984375 |
| candidate best ensemble holdout | 0.1015625 |
| ensemble holdout delta | 0.01171875 |

| gate | pass |
| --- | ---: |
| shared_panel | true |
| spearman | false |
| topk_overlap | true |
| selected_regret | false |
| speed | false |
| ensemble_quality | true |

Pass: `false`

## spectral_projected

| metric | value |
| --- | ---: |
| shared candidates | 16 |
| Spearman | 0.7354508026412337 |
| top-8 overlap | 6 |
| selected regret | 0.015625 |
| dense best cap-hit | 0.0 |
| dense best malformed | 0.0 |
| selected candidate cap-hit | 0.0 |
| selected candidate malformed | 0.0 |
| dense candidate/sec | 0.04186750445400022 |
| candidate/sec | 0.03307787844294851 |
| speed ratio candidate/dense | 0.7900609046161597 |
| dense mean mutation s | 1.4850405603647232 |
| candidate mean mutation s | 0.24332962930202484 |
| mutation ratio candidate/dense | 0.1638538608280595 |
| dense best ensemble holdout | 0.08984375 |
| candidate best ensemble holdout | 0.08984375 |
| ensemble holdout delta | 0.0 |

| gate | pass |
| --- | ---: |
| shared_panel | true |
| spearman | false |
| topk_overlap | true |
| selected_regret | false |
| speed | false |
| ensemble_quality | true |

Pass: `false`

Overall pass: `false`
