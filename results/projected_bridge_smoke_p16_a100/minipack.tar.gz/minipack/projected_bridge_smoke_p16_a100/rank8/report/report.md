# Dense Gaussian Parity Report

## lora

| metric | value |
| --- | ---: |
| shared candidates | 16 |
| Spearman | -0.04183927527551931 |
| top-8 overlap | 4 |
| selected regret | 0.015625 |
| dense best cap-hit | 0.0 |
| dense best malformed | 0.0 |
| selected candidate cap-hit | 0.0 |
| selected candidate malformed | 0.015625 |
| dense candidate/sec | 0.04186750445400022 |
| candidate/sec | 0.035217780892570605 |
| speed ratio candidate/dense | 0.8411722014925523 |
| dense best ensemble holdout | 0.08984375 |
| candidate best ensemble holdout | 0.0859375 |
| ensemble holdout delta | -0.00390625 |

| gate | pass |
| --- | ---: |
| shared_panel | true |
| spearman | false |
| topk_overlap | false |
| selected_regret | false |
| speed | false |
| ensemble_quality | false |

Pass: `false`

## projected

| metric | value |
| --- | ---: |
| shared candidates | 16 |
| Spearman | 0.13673300264486338 |
| top-8 overlap | 4 |
| selected regret | 0.015625 |
| dense best cap-hit | 0.0 |
| dense best malformed | 0.0 |
| selected candidate cap-hit | 0.0 |
| selected candidate malformed | 0.0 |
| dense candidate/sec | 0.04186750445400022 |
| candidate/sec | 0.010133960290557952 |
| speed ratio candidate/dense | 0.2420483480617318 |
| dense best ensemble holdout | 0.08984375 |
| candidate best ensemble holdout | 0.08203125 |
| ensemble holdout delta | -0.0078125 |

| gate | pass |
| --- | ---: |
| shared_panel | true |
| spearman | false |
| topk_overlap | false |
| selected_regret | false |
| speed | false |
| ensemble_quality | false |

Pass: `false`

Overall pass: `false`
