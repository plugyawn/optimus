# Dense Gaussian Parity Report

## lora

| metric | value |
| --- | ---: |
| shared candidates | 16 |
| Spearman | -0.07812754060909646 |
| top-8 overlap | 3 |
| selected regret | 0.0 |
| dense best cap-hit | 0.0 |
| dense best malformed | 0.0 |
| selected candidate cap-hit | 0.0 |
| selected candidate malformed | 0.0 |
| dense candidate/sec | 0.04186750445400022 |
| candidate/sec | 0.036885864075668844 |
| speed ratio candidate/dense | 0.8810141554100819 |
| dense mean mutation s | 1.4850405603647232 |
| candidate mean mutation s | 0.18554235994815826 |
| mutation ratio candidate/dense | 0.12494093757451945 |
| dense best ensemble holdout | 0.08984375 |
| candidate best ensemble holdout | 0.09765625 |
| ensemble holdout delta | 0.0078125 |

| gate | pass |
| --- | ---: |
| shared_panel | true |
| spearman | false |
| topk_overlap | false |
| selected_regret | true |
| speed | false |
| ensemble_quality | true |

Pass: `false`

## randomized_projected

| metric | value |
| --- | ---: |
| shared candidates | 16 |
| Spearman | 0.7401656869827914 |
| top-8 overlap | 6 |
| selected regret | 0.0 |
| dense best cap-hit | 0.0 |
| dense best malformed | 0.0 |
| selected candidate cap-hit | 0.0 |
| selected candidate malformed | 0.0 |
| dense candidate/sec | 0.04186750445400022 |
| candidate/sec | 0.02901760472879341 |
| speed ratio candidate/dense | 0.6930817851987099 |
| dense mean mutation s | 1.4850405603647232 |
| candidate mean mutation s | 4.420480862259865 |
| mutation ratio candidate/dense | 2.9766734863956867 |
| dense best ensemble holdout | 0.08984375 |
| candidate best ensemble holdout | 0.08984375 |
| ensemble holdout delta | 0.0 |

| gate | pass |
| --- | ---: |
| shared_panel | true |
| spearman | false |
| topk_overlap | true |
| selected_regret | true |
| speed | false |
| ensemble_quality | true |

Pass: `false`

## spectral_projected

| metric | value |
| --- | ---: |
| shared candidates | 16 |
| Spearman | 0.3425634307822216 |
| top-8 overlap | 4 |
| selected regret | 0.0 |
| dense best cap-hit | 0.0 |
| dense best malformed | 0.0 |
| selected candidate cap-hit | 0.0 |
| selected candidate malformed | 0.0 |
| dense candidate/sec | 0.04186750445400022 |
| candidate/sec | 0.03354062186696032 |
| speed ratio candidate/dense | 0.8011134722350449 |
| dense mean mutation s | 1.4850405603647232 |
| candidate mean mutation s | 0.4962102323770523 |
| mutation ratio candidate/dense | 0.33413917816169547 |
| dense best ensemble holdout | 0.08984375 |
| candidate best ensemble holdout | 0.08203125 |
| ensemble holdout delta | -0.0078125 |

| gate | pass |
| --- | ---: |
| shared_panel | true |
| spearman | false |
| topk_overlap | false |
| selected_regret | true |
| speed | false |
| ensemble_quality | false |

Pass: `false`

Overall pass: `false`
