# Dense Gaussian Parity Report

## lora

| metric | value |
| --- | ---: |
| shared candidates | 16 |
| Spearman | 0.10813008130081299 |
| top-8 overlap | 4 |
| selected regret | 0.046875 |
| dense best cap-hit | 0.0 |
| dense best malformed | 0.0 |
| selected candidate cap-hit | 0.0 |
| selected candidate malformed | 0.0 |
| dense candidate/sec | 0.04186750445400022 |
| candidate/sec | 0.03536823327364456 |
| speed ratio candidate/dense | 0.8447657374110653 |
| dense mean mutation s | 1.4850405603647232 |
| candidate mean mutation s | 0.07420630753040314 |
| mutation ratio candidate/dense | 0.049969212633611974 |
| dense best ensemble holdout | 0.08984375 |
| candidate best ensemble holdout | 0.08984375 |
| ensemble holdout delta | 0.0 |

| gate | pass |
| --- | ---: |
| shared_panel | true |
| spearman | false |
| topk_overlap | false |
| selected_regret | false |
| speed | false |
| ensemble_quality | true |

Pass: `false`

## spectral_c0p5

| metric | value |
| --- | ---: |
| shared candidates | 16 |
| Spearman | 0.6250203248727717 |
| top-8 overlap | 5 |
| selected regret | 0.0 |
| dense best cap-hit | 0.0 |
| dense best malformed | 0.0 |
| selected candidate cap-hit | 0.0 |
| selected candidate malformed | 0.0 |
| dense candidate/sec | 0.04186750445400022 |
| candidate/sec | 0.03530654301119375 |
| speed ratio candidate/dense | 0.8432922733664484 |
| dense mean mutation s | 1.4850405603647232 |
| candidate mean mutation s | 0.22860494256019592 |
| mutation ratio candidate/dense | 0.15393851768200256 |
| dense best ensemble holdout | 0.08984375 |
| candidate best ensemble holdout | 0.1015625 |
| ensemble holdout delta | 0.01171875 |

| gate | pass |
| --- | ---: |
| shared_panel | true |
| spearman | false |
| topk_overlap | false |
| selected_regret | true |
| speed | false |
| ensemble_quality | true |

Pass: `false`

## spectral_c0p75

| metric | value |
| --- | ---: |
| shared candidates | 16 |
| Spearman | 0.31111294989876415 |
| top-8 overlap | 6 |
| selected regret | 0.0 |
| dense best cap-hit | 0.0 |
| dense best malformed | 0.0 |
| selected candidate cap-hit | 0.0 |
| selected candidate malformed | 0.0 |
| dense candidate/sec | 0.04186750445400022 |
| candidate/sec | 0.034994558079414914 |
| speed ratio candidate/dense | 0.8358405530920382 |
| dense mean mutation s | 1.4850405603647232 |
| candidate mean mutation s | 0.20294055342674255 |
| mutation ratio candidate/dense | 0.13665657278539298 |
| dense best ensemble holdout | 0.08984375 |
| candidate best ensemble holdout | 0.078125 |
| ensemble holdout delta | -0.01171875 |

| gate | pass |
| --- | ---: |
| shared_panel | true |
| spearman | false |
| topk_overlap | true |
| selected_regret | true |
| speed | false |
| ensemble_quality | false |

Pass: `false`

## spectral_c1p25

| metric | value |
| --- | ---: |
| shared candidates | 16 |
| Spearman | 0.5669539204974948 |
| top-8 overlap | 6 |
| selected regret | 0.015625 |
| dense best cap-hit | 0.0 |
| dense best malformed | 0.0 |
| selected candidate cap-hit | 0.0 |
| selected candidate malformed | 0.0 |
| dense candidate/sec | 0.04186750445400022 |
| candidate/sec | 0.03557868781162767 |
| speed ratio candidate/dense | 0.8497924171887994 |
| dense mean mutation s | 1.4850405603647232 |
| candidate mean mutation s | 0.1953759789466858 |
| mutation ratio candidate/dense | 0.13156272236678965 |
| dense best ensemble holdout | 0.08984375 |
| candidate best ensemble holdout | 0.09375 |
| ensemble holdout delta | 0.00390625 |

| gate | pass |
| --- | ---: |
| shared_panel | true |
| spearman | false |
| topk_overlap | true |
| selected_regret | false |
| speed | false |
| ensemble_quality | true |

Pass: `false`

## spectral_c1p5

| metric | value |
| --- | ---: |
| shared candidates | 16 |
| Spearman | 0.7019027699454979 |
| top-8 overlap | 6 |
| selected regret | 0.0 |
| dense best cap-hit | 0.0 |
| dense best malformed | 0.0 |
| selected candidate cap-hit | 0.0 |
| selected candidate malformed | 0.0 |
| dense candidate/sec | 0.04186750445400022 |
| candidate/sec | 0.036395832515845924 |
| speed ratio candidate/dense | 0.869309814150351 |
| dense mean mutation s | 1.4850405603647232 |
| candidate mean mutation s | 0.2647661715745926 |
| mutation ratio candidate/dense | 0.17828884856152785 |
| dense best ensemble holdout | 0.08984375 |
| candidate best ensemble holdout | 0.1015625 |
| ensemble holdout delta | 0.01171875 |

| gate | pass |
| --- | ---: |
| shared_panel | true |
| spearman | false |
| topk_overlap | true |
| selected_regret | true |
| speed | false |
| ensemble_quality | true |

Pass: `false`

## spectral_c2

| metric | value |
| --- | ---: |
| shared candidates | 16 |
| Spearman | 0.5403990052149736 |
| top-8 overlap | 5 |
| selected regret | 0.0 |
| dense best cap-hit | 0.0 |
| dense best malformed | 0.0 |
| selected candidate cap-hit | 0.0 |
| selected candidate malformed | 0.0 |
| dense candidate/sec | 0.04186750445400022 |
| candidate/sec | 0.03562241796828958 |
| speed ratio candidate/dense | 0.8508369063990401 |
| dense mean mutation s | 1.4850405603647232 |
| candidate mean mutation s | 0.1820785254240036 |
| mutation ratio candidate/dense | 0.1226084527814415 |
| dense best ensemble holdout | 0.08984375 |
| candidate best ensemble holdout | 0.08984375 |
| ensemble holdout delta | 0.0 |

| gate | pass |
| --- | ---: |
| shared_panel | true |
| spearman | false |
| topk_overlap | false |
| selected_regret | true |
| speed | false |
| ensemble_quality | true |

Pass: `false`

Overall pass: `false`
