# Dense Gaussian Parity Report

## lora

| metric | value |
| --- | ---: |
| shared candidates | 16 |
| Spearman | -0.07812754060909646 |
| top-8 overlap | 3 |
| selected regret | 0.0 |
| dense best cap-hit | 0.0 |
| dense best malformed | 0.0 |
| selected candidate cap-hit | 0.0 |
| selected candidate malformed | 0.0 |
| dense candidate/sec | 0.04186750445400022 |
| candidate/sec | 0.036885864075668844 |
| speed ratio candidate/dense | 0.8810141554100819 |
| dense mean mutation s | 1.4850405603647232 |
| candidate mean mutation s | 0.18554235994815826 |
| mutation ratio candidate/dense | 0.12494093757451945 |
| dense best ensemble holdout | 0.08984375 |
| candidate best ensemble holdout | 0.09765625 |
| ensemble holdout delta | 0.0078125 |

| gate | pass |
| --- | ---: |
| shared_panel | true |
| spearman | false |
| topk_overlap | false |
| selected_regret | true |
| speed | false |
| ensemble_quality | true |

Pass: `false`

## spectral_c0p5

| metric | value |
| --- | ---: |
| shared candidates | 16 |
| Spearman | 0.17598789244948487 |
| top-8 overlap | 3 |
| selected regret | 0.0 |
| dense best cap-hit | 0.0 |
| dense best malformed | 0.0 |
| selected candidate cap-hit | 0.0 |
| selected candidate malformed | 0.0 |
| dense candidate/sec | 0.04186750445400022 |
| candidate/sec | 0.035344546547093035 |
| speed ratio candidate/dense | 0.8441999829707082 |
| dense mean mutation s | 1.4850405603647232 |
| candidate mean mutation s | 0.49621596932411194 |
| mutation ratio candidate/dense | 0.3341430413201928 |
| dense best ensemble holdout | 0.08984375 |
| candidate best ensemble holdout | 0.08984375 |
| ensemble holdout delta | 0.0 |

| gate | pass |
| --- | ---: |
| shared_panel | true |
| spearman | false |
| topk_overlap | false |
| selected_regret | true |
| speed | false |
| ensemble_quality | true |

Pass: `false`

## spectral_c1p5

| metric | value |
| --- | ---: |
| shared candidates | 16 |
| Spearman | 0.5225976393774916 |
| top-8 overlap | 5 |
| selected regret | 0.0 |
| dense best cap-hit | 0.0 |
| dense best malformed | 0.0 |
| selected candidate cap-hit | 0.0 |
| selected candidate malformed | 0.0 |
| dense candidate/sec | 0.04186750445400022 |
| candidate/sec | 0.035281285713410444 |
| speed ratio candidate/dense | 0.8426890060326847 |
| dense mean mutation s | 1.4850405603647232 |
| candidate mean mutation s | 0.432524636387825 |
| mutation ratio candidate/dense | 0.2912544262640192 |
| dense best ensemble holdout | 0.08984375 |
| candidate best ensemble holdout | 0.08203125 |
| ensemble holdout delta | -0.0078125 |

| gate | pass |
| --- | ---: |
| shared_panel | true |
| spearman | false |
| topk_overlap | false |
| selected_regret | true |
| speed | false |
| ensemble_quality | false |

Pass: `false`

Overall pass: `false`
